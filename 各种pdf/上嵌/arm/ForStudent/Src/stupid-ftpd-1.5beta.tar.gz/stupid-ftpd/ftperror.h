
#define RET_150  0
#define RET_501  1
#define RET_226  2
#define RET_221  3
#define RET_425  4
#define RET_428  5
#define RET_429  6
#define RET_530  7
#define RET_220  8
#define RET_331  9
#define RET_531 10
#define RET_532 11
#define RET_533 12
#define RET_534 13
#define RET_422 14
#define RET_423 15
#define RET_215 16
#define RET_500 17
#define RET_502 18
#define RET_200 19
#define RET_250 20
#define RET_553 21
#define RET_350 22
#define RET_451 23
#define RET_209 24
#define RET_503 25
#define RET_227 26
#define RET_591 27
#define RET_491 28
#define RET_257 29
#define RET_258 30
#define RET_259 31
#define RET_540 32
#define RET_550 33


extern const char *ftp_returnstr[];
