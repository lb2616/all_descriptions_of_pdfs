
/*

  command.h
  ---------


  Header for command.c

 */


extern void execcmd(char *);
